package gamebox;

public class GameBox {

    public static void main(String[] args) {
       Selector x=new Selector();
       x.setVisible(true);
    }
    
}
